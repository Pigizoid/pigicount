Use the function like 
list1 = pigi.sort(list1) 

Benchmarks for sorting:
10 million elements in 1 second with 8 GB of RAM 

btw: more RAM = Faster speeds